import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Muskan Prasad - Computer Science Student & Web Developer",
  description:
    "Passionate Computer Science student specializing in web development. I create innovative and scalable digital solutions, transforming ideas into seamless applications.",
  keywords: "Muskan Prasad, Computer Science, Web Developer, Portfolio, React, Next.js, JavaScript, HTML, CSS",
  authors: [{ name: "Muskan Prasad" }],
  creator: "Muskan Prasad",
  publisher: "Muskan Prasad",
  robots: "index, follow",
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://muskannport.vercel.app/",
    title: "Muskan Prasad - Computer Science Student & Web Developer",
    description:
      "Passionate Computer Science student specializing in web development. I create innovative and scalable digital solutions, transforming ideas into seamless applications.",
    siteName: "Muskan Prasad Portfolio",
    images: [
      {
        url: "/images/muskan-photo.jpg", // Updated to new photo
        width: 1200,
        height: 630,
        alt: "Muskan Prasad - Computer Science Student",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Muskan Prasad - Computer Science Student & Web Developer",
    description:
      "Passionate Computer Science student specializing in web development. I create innovative and scalable digital solutions.",
    images: ["/images/muskan-photo.jpg"], // Updated to new photo
    creator: "@muskanprasad",
  },
  viewport: "width=device-width, initial-scale=1",
  themeColor: "#8b5cf6",
  manifest: "/manifest.json",
  icons: {
    icon: "/favicon.ico",
    shortcut: "/favicon-16x16.png",
    apple: "/apple-touch-icon.png",
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head>
        <meta name="application-name" content="Muskan Prasad Portfolio" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
        <meta name="apple-mobile-web-app-title" content="Muskan Prasad Portfolio" />
        <meta name="format-detection" content="telephone=no" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="msapplication-config" content="/browserconfig.xml" />
        <meta name="msapplication-TileColor" content="#8b5cf6" />
        <meta name="msapplication-tap-highlight" content="no" />
        <meta property="og:site_name" content="Muskan Prasad Portfolio" />
        <meta property="og:locale" content="en_US" />
        <meta property="og:title" content="Muskan Prasad - Computer Science Student & Web Developer" />
        <meta
          property="og:description"
          content="Passionate Computer Science student specializing in web development. I create innovative and scalable digital solutions."
        />
        <meta property="og:image:width" content="1200" />
        <meta property="og:image:height" content="630" />
        <meta property="og:image:type" content="image/jpeg" />
        <meta name="generator" content="Next.js" />
        <meta name="referrer" content="origin-when-cross-origin" />
      </head>
      <body className={inter.className}>{children}</body>
    </html>
  )
}
