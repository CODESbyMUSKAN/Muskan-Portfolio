"use client"

import type React from "react"

import { useState, useEffect, useRef, useCallback } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  Moon,
  Sun,
  Menu,
  X,
  Mail,
  Phone,
  MapPin,
  Linkedin,
  Github,
  Download,
  GraduationCap,
  ArrowUp,
  Code,
  Globe,
  Palette,
  Server,
  Briefcase,
} from "lucide-react"
import DarkVeil from "@/components/DarkVeil"
import ShinyText from "@/components/ShinyText"
import InteractiveCard from "@/components/interactive-card"
import GlobalSpotlight from "@/components/global-spotlight"
import GradientText from "@/components/GradientText"
import DecryptedText from "@/components/DecryptedText"
import TextGenerateEffect from "@/components/ui/text-generate-effect"
import TiltedCard from "@/components/TiltedCard"

export default function Portfolio() {
  const [darkMode, setDarkMode] = useState(true)
  const [activeSection, setActiveSection] = useState("home")
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [showScrollTop, setShowScrollTop] = useState(false)

  // State for contact form fields
  const [contactName, setContactName] = useState("")
  const [contactEmail, setContactEmail] = useState("")
  const [contactMessage, setContactMessage] = useState("")

  const aboutMeGridRef = useRef<HTMLDivElement>(null)

  // Optimized scroll handler with throttling
  const throttledScrollHandler = useCallback(() => {
    let ticking = false

    const updateScrollState = () => {
      const scrollY = window.scrollY
      setShowScrollTop(scrollY > 300)

      // Update active section based on scroll position with better performance
      const sections = ["home", "about", "services", "projects", "certifications", "contact"]
      let current = activeSection

      for (const section of sections) {
        const element = document.getElementById(section)
        if (element) {
          const rect = element.getBoundingClientRect()
          const elementTop = rect.top + scrollY
          const elementBottom = elementTop + rect.height

          if (scrollY >= elementTop - 150 && scrollY < elementBottom - 150) {
            current = section
            break
          }
        }
      }

      if (current !== activeSection) {
        setActiveSection(current)
      }
      ticking = false
    }

    return () => {
      if (!ticking) {
        requestAnimationFrame(updateScrollState)
        ticking = true
      }
    }
  }, [activeSection])

  useEffect(() => {
    const handleScroll = throttledScrollHandler()

    // Use passive listeners for better performance
    window.addEventListener("scroll", handleScroll, { passive: true })
    return () => window.removeEventListener("scroll", handleScroll)
  }, [throttledScrollHandler])

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const scrollToSection = useCallback((sectionId: string) => {
    const element = document.getElementById(sectionId)
    if (element) {
      const headerHeight = 80 // Assuming navbar height is 16 (64px)
      const elementPosition = element.getBoundingClientRect().top + window.pageYOffset
      const offsetPosition = elementPosition - headerHeight

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth",
      })
    }
    setIsMenuOpen(false)
  }, [])

  // Function to handle sending email
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault() // Prevent default form submission

    const recipientEmail = "muskan.prasad.18@gmail.com"
    const subject = encodeURIComponent(`Message from ${contactName} via Portfolio`)
    const body = encodeURIComponent(`Name: ${contactName}\nEmail: ${contactEmail}\n\nMessage:\n${contactMessage}`)

    window.location.href = `mailto:${recipientEmail}?subject=${subject}&body=${body}`

    // Optionally clear form fields after attempting to send
    setContactName("")
    setContactEmail("")
    setContactMessage("")
  }

  const navItems = [
    { id: "home", label: "Home" },
    { id: "about", label: "About" },
    { id: "services", label: "Services" },
    { id: "projects", label: "Projects" },
    { id: "certifications", label: "Certifications" },
    { id: "contact", label: "Contact" },
  ]

  const services = [
    {
      icon: Code,
      title: "Full Stack Development",
      description: "End-to-end web application development using modern technologies and frameworks.",
    },
    {
      icon: Server,
      title: "Back-end Development",
      description: "Robust server-side development with databases, APIs, and scalable architecture.",
    },
    {
      icon: Palette,
      title: "UI/UX Design",
      description: "Creative and intuitive user interface design with focus on user experience.",
    },
    {
      icon: Globe,
      title: "Web Design",
      description: "Responsive and modern web design that works perfectly across all devices.",
    },
  ]

  const projects = [
    {
      title: "Personal Portfolio",
      description:
        "A clean and elegant web portfolio for designers and developers that includes everything essential to showcase skills and projects.",
      techStack: ["HTML", "CSS", "JavaScript", "Tailwind CSS"],
      features: ["Responsive Design", "Smooth Animations", "User-friendly Interface", "Modern Layout"],
      codeLink: "https://github.com/CODESbyMUSKAN/muskan-portfolio", // Updated link
      liveDemoLink: "https://muskannnportfolio.vercel.app",
    },
    {
      title: "Milina Nail Salon",
      description:
        "A responsive and elegant nail salon website showcasing key services such as nail art, manicure, pedicure, and treatments.",
      techStack: ["HTML", "CSS", "JavaScript", "React"],
      features: ["Service Showcase", "Appointment Booking", "Mobile Optimized", "Interactive Frontend"],
      codeLink: "https://github.com/CODESbyMUSKAN/Milina-by-Muskan", // Updated link
      liveDemoLink: "https://github.com/CODESbyMUSKAN/Milina-by-Muskan", // Updated link
    },
    {
      title: "VoyageVista Travel Platform",
      description:
        "A travel discovery platform for exploring destinations, creating itineraries, and sharing travel stories.",
      techStack: ["React", "Next.js", "Tailwind CSS", "MongoDB"],
      features: [
        "Interactive Destination Search",
        "Personalized Itinerary Builder",
        "User-generated Travel Stories",
        "Responsive Design for all devices",
        "Social Sharing Capabilities",
      ],
      liveDemoLink: "https://voyagevistadotin.vercel.app/",
      codeLink: "https://github.com/CODESbyMUSKAN", // Updated link
    },
    {
      title: "Yum Express",
      description: "Food delivery application with real-time tracking, built using Core Java, MySQL, and Swing.",
      techStack: ["Java", "MySQL", "Swing", "NetBeans"],
      features: ["User Authentication", "Restaurant Browsing", "Order Management", "Real-time Tracking"],
      codeLink: null, // Changed from "#" to null
      liveDemoLink: null, // Changed from "#" to null
      status: "Coming Soon",
    },
  ]

  const certifications = [
    {
      title: "HTML, CSS, and JavaScript: Building the Web",
      issuer: "LinkedIn Learning",
      date: "May 11, 2025",
      link: "https://www.linkedin.com/learning/certificates/8180e0a051cf1f53e3ab0534ca28a6f1a0f37367a05706097cad234b2e1bc",
      imageSrc: "/images/certifications/linkedin-html-css-js.png",
    },
    {
      title: "Database Management System Part - 1",
      issuer: "Infosys Springboard",
      date: "December 21, 2024",
      link: "https://verify.onwingspan.com",
      imageSrc: "/images/certifications/infosys-dbms.png",
    },
    {
      title: "Start Programming in Core JAVA",
      issuer: "Infosys Springboard",
      date: "September 23, 2024",
      link: "https://verify.onwingspan.com",
      imageSrc: "/images/certifications/infosys-java.png",
    },
    {
      title: "Cybersecurity Essentials",
      issuer: "Cisco Networking Academy",
      date: "Jun 5, 2023",
      link: "#",
      imageSrc: "/images/certifications/cisco-cybersecurity.png",
    },
    {
      title: "Generative AI Virtual Internship Program",
      issuer: "Skillible / AICTE",
      date: "18 Sep 2024",
      link: "#",
      imageSrc: "/images/certifications/skillible-generative-ai.png",
    },
  ]

  const themeClasses = {
    cardBg: darkMode ? "bg-gray-800/80 backdrop-blur-sm" : "bg-white/80 backdrop-blur-sm",
    cardBorder: darkMode ? "border-gray-700/50" : "border-gray-200/50",
    text: darkMode ? "text-white" : "text-gray-900",
    textSecondary: darkMode ? "text-gray-300" : "text-gray-600",
    textMuted: darkMode ? "text-gray-400" : "text-gray-500",
    navBg: darkMode ? "bg-gray-900/95" : "bg-white/95",
    navBorder: darkMode ? "border-gray-800" : "border-gray-200",
    hoverBg: darkMode ? "hover:bg-gray-800/50" : "hover:bg-gray-100/50",
    inputBg: darkMode ? "bg-gray-700/50" : "bg-gray-100/50",
    inputBorder: darkMode ? "border-gray-600/50" : "border-gray-300/50",
  }

  return (
    <div className={`relative min-h-screen scroll-container ${darkMode ? "dark" : ""}`}>
      {/* DarkVeil Background Animation */}
      <div style={{ position: "fixed", inset: 0, zIndex: 0 }}>
        <DarkVeil
          hueShift={darkMode ? 280 : 320}
          noiseIntensity={0.02}
          scanlineIntensity={0.05}
          speed={0.5}
          scanlineFrequency={100}
          warpAmount={0.02}
          resolutionScale={1}
        />
        {!darkMode && (
          <div
            style={{
              position: "absolute",
              inset: 0,
              backgroundColor: "rgba(255, 200, 230, 0.5)",
              pointerEvents: "none",
            }}
          />
        )}
      </div>

      {/* Global Spotlight for About Me section */}
      <GlobalSpotlight
        gridRef={aboutMeGridRef}
        disableAnimations={false}
        enabled={true}
        spotlightRadius={300}
        glowColor="132, 0, 255"
      />

      {/* Main Portfolio Content */}
      <div className={`relative z-10 min-h-screen transition-colors duration-300 ${themeClasses.text}`}>
        {/* Navigation */}
        <nav
          className={`fixed top-0 w-full z-[600] backdrop-blur-sm border-b transition-colors duration-300 optimized-animation ${themeClasses.navBg} ${themeClasses.navBorder}`}
          style={{ willChange: "transform" }}
        >
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              {/* Logo */}
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center text-white font-bold text-lg shadow-lg"
              >
                M
              </motion.div>

              {/* Desktop Navigation */}
              <div className="hidden md:flex space-x-4 lg:space-x-8">
                {navItems.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => scrollToSection(item.id)}
                    className={`px-3 lg:px-4 py-2 rounded-full transition-all duration-200 text-sm lg:text-base ${
                      activeSection === item.id
                        ? "bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg"
                        : `${themeClasses.textSecondary} hover:text-purple-500 ${themeClasses.hoverBg}`
                    }`}
                  >
                    <ShinyText text={item.label} />
                  </button>
                ))}
              </div>

              {/* Right Side */}
              <div className="flex items-center space-x-2 lg:space-x-4">
                <button
                  onClick={() => setDarkMode(!darkMode)}
                  className={`p-2 rounded-lg transition-colors duration-200 ${themeClasses.textMuted} ${themeClasses.hoverBg}`}
                >
                  {darkMode ? <Sun size={20} /> : <Moon size={20} />}
                </button>

                <button
                  onClick={() => scrollToSection("contact")}
                  className="hidden md:block px-3 lg:px-4 py-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-full hover:from-purple-600 hover:to-pink-600 transition-all duration-200 shadow-lg hover:shadow-xl text-sm lg:text-base"
                >
                  Contact
                </button>

                <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="md:hidden p-2 rounded-lg">
                  {isMenuOpen ? <X size={20} /> : <Menu size={20} />}
                </button>
              </div>
            </div>
          </div>
        </nav>

        {/* Mobile Navigation */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              initial={{ opacity: 0, y: "-100vh" }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: "-100vh" }}
              transition={{ duration: 0.3, ease: "easeOut" }}
              className={`fixed inset-0 z-[700] md:hidden flex flex-col items-center justify-start pt-20 space-y-6 ${themeClasses.navBg}`}
            >
              <button onClick={() => setIsMenuOpen(false)} className="absolute top-4 right-4 p-2 rounded-lg text-white">
                <X size={24} />
              </button>
              <div className="px-4 py-2 space-y-4 text-center w-full max-w-sm">
                {navItems.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => scrollToSection(item.id)}
                    className={`block w-full text-center px-3 py-2 rounded-lg transition-colors text-xl lg:text-2xl font-bold ${
                      activeSection === item.id
                        ? "bg-gradient-to-r from-purple-500 to-pink-500 text-white"
                        : `${themeClasses.textSecondary} ${themeClasses.hoverBg}`
                    }`}
                  >
                    <ShinyText text={item.label} />
                  </button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Hero Section */}
        <section id="home" className="pt-16 min-h-screen relative z-10 prevent-shift">
          <div className="min-h-screen flex items-center">
            <div className="w-full grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-center px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto py-8 lg:py-0">
              {/* Left Side - Content */}
              <div className="order-2 lg:order-1 space-y-4 lg:space-y-6 text-center lg:text-left">
                <motion.div
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8 }}
                  className="space-y-4 lg:space-y-6"
                >
                  {/* Welcome Text */}
                  <div
                    className={`flex items-center justify-center lg:justify-start space-x-2 text-sm lg:text-base ${themeClasses.textSecondary}`}
                  >
                    <DecryptedText
                      text="WELCOME TO MY WORLD"
                      animateOn="view"
                      sequential={true}
                      speed={70}
                      maxIterations={1}
                    />
                    <span className="text-yellow-400">✨</span>
                  </div>

                  {/* Main Heading */}
                  <div className="space-y-2 lg:space-y-4">
                    <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-bold leading-tight">
                      <GradientText colors={["#a855f7", "#ec4899", "#a855f7"]} animationSpeed={3}>
                        Hi, I'm Muskan
                        <br />
                        Prasad
                      </GradientText>
                    </h1>
                  </div>

                  {/* Description */}
                  <p
                    className={`text-sm sm:text-base lg:text-lg max-w-lg mx-auto lg:mx-0 leading-relaxed ${themeClasses.textSecondary}`}
                  >
                    <TextGenerateEffect
                      words="Passionate Computer Science student. I create innovative and scalable digital solutions. I transform ideas into seamless applications that exceed expectations."
                      textColorClass={themeClasses.textSecondary}
                    />
                  </p>

                  {/* Action Buttons */}
                  <div className="flex flex-col sm:flex-row gap-3 lg:gap-4 pt-4 items-center justify-center lg:justify-start">
                    <button
                      onClick={() => scrollToSection("projects")}
                      className="w-full sm:w-auto px-6 lg:px-8 py-3 lg:py-4 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-full hover:from-purple-600 hover:to-pink-600 transition-all duration-200 font-medium shadow-lg hover:shadow-xl transform hover:scale-105 text-sm lg:text-base"
                    >
                      <DecryptedText text="My Projects" animateOn="hover" />
                    </button>
                    <a
                      href="/muskan_resume.pdf"
                      download="Muskan_Prasad_Resume.pdf"
                      className={`w-full sm:w-auto px-6 lg:px-8 py-3 lg:py-4 bg-transparent border-2 rounded-full transition-all duration-200 font-medium flex items-center justify-center space-x-2 text-sm lg:text-base ${darkMode ? "border-gray-600 text-white hover:bg-gray-800/50" : "border-gray-300 text-gray-900 hover:bg-gray-100/50"}`}
                    >
                      <Download size={16} className="lg:w-5 lg:h-5" />
                      <DecryptedText text="Download CV" animateOn="hover" />
                    </a>
                  </div>

                  {/* Social Links */}
                  <div className="flex justify-center lg:justify-start space-x-3 lg:space-x-4 pt-4">
                    {[
                      { icon: Github, href: "https://github.com/CODESbyMUSKAN" },
                      { icon: Linkedin, href: "https://www.linkedin.com/in/muskan-prasad-562132275/" },
                      { icon: Mail, href: "mailto:muskan.prasad.18@gmail.com" },
                      { icon: Phone, href: "tel:8962819870" },
                    ].map((social, index) => (
                      <a
                        key={index}
                        href={social.href}
                        target="_blank"
                        rel="noopener noreferrer"
                        className={`w-10 h-10 sm:w-12 sm:h-12 lg:w-14 lg:h-14 rounded-full flex items-center justify-center transition-all duration-200 shadow-lg hover:shadow-xl transform hover:scale-110 ${darkMode ? "bg-gray-800/80 text-gray-400 hover:text-white hover:bg-gray-700/80 backdrop-blur-sm" : "bg-white/80 text-gray-600 hover:text-purple-500 hover:bg-gray-50/80 border border-gray-200/50 backdrop-blur-sm"}`}
                      >
                        <social.icon size={18} className="sm:w-5 sm:h-5" />
                      </a>
                    ))}
                  </div>
                </motion.div>
              </div>

              {/* Right Side - Profile Card */}
              <div className="order-1 lg:order-2 flex items-center justify-center">
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.8, delay: 0.2 }}
                  className="relative w-full max-w-xs sm:max-w-sm lg:max-w-md"
                >
                  {/* Profile Card */}
                  <div
                    className={`rounded-3xl p-4 sm:p-6 lg:p-8 text-white relative overflow-hidden shadow-2xl border backdrop-blur-sm ${darkMode ? "bg-gray-800/80 border-gray-700/50" : "bg-gray-800/90 border-gray-300/50"}`}
                  >
                    {/* Three Dots */}
                    <div className="absolute top-3 sm:top-4 lg:top-6 right-3 sm:right-4 lg:right-6 flex space-x-1">
                      <div className="w-2 h-2 lg:w-3 lg:h-3 bg-purple-500 rounded-full"></div>
                      <div className="w-2 h-2 lg:w-3 lg:h-3 bg-pink-500 rounded-full"></div>
                      <div className="w-2 h-2 lg:w-3 lg:h-3 bg-green-500 rounded-full"></div>
                    </div>

                    {/* Profile Image */}
                    <div className="mb-3 sm:mb-4 lg:mb-6">
                      <div className="w-24 h-24 sm:w-32 sm:h-32 lg:w-40 lg:h-40 mx-auto rounded-full overflow-hidden border-4 border-purple-500/30 shadow-xl">
                        <img
                          src="/images/muskan-photo.jpg"
                          alt="Muskan Prasad"
                          className="w-full h-full object-cover"
                        />
                      </div>
                    </div>

                    {/* Profile Info */}
                    <div className="text-center space-y-1 sm:space-y-2 lg:space-y-3">
                      <h1 className="text-lg sm:text-xl lg:text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400">
                        <DecryptedText text="Muskan Prasad" animateOn="hover" />
                      </h1>
                      <p className="text-gray-300 text-sm sm:text-base lg:text-lg">
                        <DecryptedText text="Computer Science Student" animateOn="hover" />
                      </p>

                      {/* Status */}
                      <div className="flex items-center justify-center space-x-2 mt-2 sm:mt-4">
                        <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                        <span className="text-green-400 text-xs sm:text-sm">
                          <DecryptedText text="Available for work" animateOn="hover" />
                        </span>
                      </div>
                    </div>

                    {/* Background Pattern */}
                    <div className="absolute inset-0 opacity-10">
                      <div className="absolute top-0 right-0 w-24 sm:w-32 h-24 sm:h-32 bg-purple-500 rounded-full blur-3xl"></div>
                      <div className="absolute bottom-0 left-0 w-16 sm:w-24 h-16 sm:h-24 bg-pink-500 rounded-full blur-2xl"></div>
                    </div>
                  </div>
                </motion.div>
              </div>
            </div>
          </div>
        </section>

        {/* About Section */}
        <section id="about" className="py-12 sm:py-16 lg:py-20 relative z-10 prevent-shift">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="text-center mb-8 sm:mb-12 lg:mb-16 optimized-animation"
            >
              <h2 className={`text-2xl sm:text-3xl lg:text-5xl font-bold mb-3 sm:mb-4 lg:mb-6 ${themeClasses.text}`}>
                About me
              </h2>
              <p className={`text-base sm:text-lg lg:text-xl max-w-4xl mx-auto ${themeClasses.textSecondary}`}>
                Welcome to my portfolio! I'm Muskan Prasad, a passionate Computer Science student
              </p>
            </motion.div>

            <div
              ref={aboutMeGridRef}
              className="bento-section grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 lg:gap-8"
            >
              {/* Education Card */}
              <InteractiveCard
                disableAnimations={false}
                enableTilt={true}
                enableMagnetism={true}
                clickEffect={true}
                glowColor="132, 0, 255"
                className={`rounded-2xl p-4 sm:p-6 lg:p-8 border transition-all duration-300 hover:border-purple-500/50 ${themeClasses.cardBg} ${themeClasses.cardBorder}`}
              >
                <motion.div
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: 0.1 }}
                  viewport={{ once: true }}
                >
                  <div className="flex items-center space-x-3 mb-4 sm:mb-6">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
                      <GraduationCap className="text-white" size={20} />
                    </div>
                    <h3 className="text-lg sm:text-xl lg:text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-500 to-pink-500">
                      Education
                    </h3>
                  </div>

                  <div className="space-y-4 sm:space-y-6">
                    <div className="border-l-2 border-purple-500 pl-3 sm:pl-4">
                      <h4 className={`text-base sm:text-lg font-bold ${themeClasses.text}`}>B.Tech CSE (IoT)</h4>
                      <p className={`text-sm ${themeClasses.textSecondary}`}>LNCT Group of Colleges</p>
                      <div className="flex justify-between items-center mt-1 sm:mt-2">
                        <span className="text-purple-500 font-semibold text-sm">CGPA: 8.68</span>
                        <span className="text-purple-500 text-xs sm:text-sm">2022-2026</span>
                      </div>
                    </div>

                    <div className="border-l-2 border-purple-500 pl-3 sm:pl-4">
                      <h4 className={`text-base sm:text-lg font-bold ${themeClasses.text}`}>Class 12th</h4>
                      <p className={`text-sm ${themeClasses.textSecondary}`}>CBSE Board</p>
                      <div className="flex justify-between items-center mt-1 sm:mt-2">
                        <span className="text-purple-500 font-semibold text-sm">84.4%</span>
                        <span className="text-purple-500 text-xs sm:text-sm">2021-2022</span>
                      </div>
                    </div>
                  </div>
                </motion.div>
              </InteractiveCard>

              {/* Skills Card */}
              <InteractiveCard
                disableAnimations={false}
                enableTilt={true}
                enableMagnetism={true}
                clickEffect={true}
                glowColor="132, 0, 255"
                className={`rounded-2xl p-4 sm:p-6 lg:p-8 border transition-all duration-300 hover:border-purple-500/50 ${themeClasses.cardBg} ${themeClasses.cardBorder}`}
              >
                <motion.div
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: 0.2 }}
                  viewport={{ once: true }}
                >
                  <div className="flex items-center space-x-3 mb-4 sm:mb-6">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
                      <Code className="text-white" size={20} />
                    </div>
                    <h3 className="text-lg sm:text-xl lg:text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-500 to-pink-500">
                      Skills
                    </h3>
                  </div>

                  <div className="space-y-4 sm:space-y-6">
                    <div className="border-l-2 border-purple-500 pl-3 sm:pl-4">
                      <h4 className={`text-base sm:text-lg font-bold mb-1 sm:mb-2 ${themeClasses.text}`}>Languages</h4>
                      <p className={`text-xs sm:text-sm ${themeClasses.textSecondary}`}>
                        Java, JavaScript, HTML, CSS, SQL
                      </p>
                    </div>

                    <div className="border-l-2 border-purple-500 pl-3 sm:pl-4">
                      <h4 className={`text-base sm:text-lg font-bold mb-1 sm:mb-2 ${themeClasses.text}`}>
                        Frameworks & Tools
                      </h4>
                      <p className={`text-xs sm:text-sm ${themeClasses.textSecondary}`}>
                        Tailwind CSS, Bootstrap, MongoDB, Git, VS Code, Eclipse IDE, IntelliJ IDEA
                      </p>
                    </div>
                  </div>
                </motion.div>
              </InteractiveCard>

              {/* Experience Card */}
              <InteractiveCard
                disableAnimations={false}
                enableTilt={true}
                enableMagnetism={true}
                clickEffect={true}
                glowColor="132, 0, 255"
                className={`rounded-2xl p-4 sm:p-6 lg:p-8 border transition-all duration-300 hover:border-purple-500/50 md:col-span-2 lg:col-span-1 ${themeClasses.cardBg} ${themeClasses.cardBorder}`}
              >
                <motion.div
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: 0.3 }}
                  viewport={{ once: true }}
                >
                  <div className="flex items-center space-x-3 mb-4 sm:mb-6">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
                      <Briefcase className="text-white" size={20} />
                    </div>
                    <h3 className="text-lg sm:text-xl lg:text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-500 to-pink-500">
                      Experience
                    </h3>
                  </div>

                  <div className="space-y-4 sm:space-y-6">
                    <div className="border-l-2 border-purple-500 pl-3 sm:pl-4">
                      <h4 className={`text-base sm:text-lg font-bold ${themeClasses.text}`}>Web Developer</h4>
                      <p className={`text-xs sm:text-sm ${themeClasses.textSecondary}`}>
                        Developed responsive web applications using modern technologies
                      </p>
                      <span className="text-purple-500 text-xs sm:text-sm">2023 - Present</span>
                    </div>

                    <div className="border-l-2 border-purple-500 pl-3 sm:pl-4">
                      <h4 className={`text-base sm:text-lg font-bold ${themeClasses.text}`}>TEDx Member</h4>
                      <p className={`text-xs sm:text-sm ${themeClasses.textSecondary}`}>
                        Organized TEDx events to inspire leadership and innovation
                      </p>
                      <span className="text-purple-500 text-xs sm:text-sm">2023</span>
                    </div>
                  </div>
                </motion.div>
              </InteractiveCard>
            </div>
          </div>
        </section>

        {/* Certifications Section */}
        <section id="certifications" className="py-12 sm:py-16 lg:py-20 relative z-10 prevent-shift">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="text-center mb-8 sm:mb-12 lg:mb-16 optimized-animation"
            >
              <h2 className={`text-2xl sm:text-3xl lg:text-5xl font-bold mb-3 sm:mb-4 lg:mb-6 ${themeClasses.text}`}>
                Certifications
              </h2>
              <p className={`text-base sm:text-lg lg:text-xl max-w-4xl mx-auto ${themeClasses.textSecondary}`}>
                My professional certifications and achievements
              </p>
            </motion.div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 lg:gap-8">
              {certifications.map((cert, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className={`rounded-2xl p-2 border transition-all duration-300 hover:border-purple-500/50 ${themeClasses.cardBg} ${themeClasses.cardBorder}`}
                >
                  <TiltedCard
                    imageSrc={cert.imageSrc}
                    altText={cert.title}
                    containerHeight="250px"
                    containerWidth="100%"
                    imageHeight="100%"
                    imageWidth="100%"
                    scaleOnHover={1.05}
                    rotateAmplitude={5}
                    showTooltip={false}
                    displayOverlayContent={true}
                    overlayContent={
                      <div className="p-3 sm:p-4">
                        <h3 className="text-base sm:text-lg lg:text-xl font-bold mb-1 sm:mb-2">{cert.title}</h3>
                        <p className="text-xs sm:text-sm">{cert.issuer}</p>
                        <p className="text-xs mt-1">{cert.date}</p>
                        {cert.link && cert.link !== "#" && (
                          <a
                            href={cert.link}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="mt-2 sm:mt-3 inline-flex items-center text-purple-300 hover:text-purple-100 transition-colors text-xs sm:text-sm"
                          >
                            View Credential <ArrowUp size={12} className="ml-1 rotate-45" />
                          </a>
                        )}
                      </div>
                    }
                  />
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Services Section */}
        <section id="services" className="py-12 sm:py-16 lg:py-20 relative z-10 prevent-shift">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="text-center mb-8 sm:mb-12 lg:mb-16 optimized-animation"
            >
              <h2 className={`text-2xl sm:text-3xl lg:text-5xl font-bold mb-3 sm:mb-4 lg:mb-6 ${themeClasses.text}`}>
                My Services
              </h2>
              <p className={`text-base sm:text-lg lg:text-xl max-w-4xl mx-auto ${themeClasses.textSecondary}`}>
                I offer a wide range of services to help you with your web development needs
              </p>
            </motion.div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 lg:gap-8">
              {services.map((service, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className={`rounded-2xl p-4 sm:p-6 lg:p-8 border transition-all duration-300 hover:border-purple-500/50 hover:scale-105 group ${themeClasses.cardBg} ${themeClasses.cardBorder}`}
                >
                  <div
                    className={`w-12 h-12 sm:w-14 sm:h-14 lg:w-16 lg:h-16 rounded-full flex items-center justify-center mb-4 sm:mb-6 group-hover:bg-gradient-to-r group-hover:from-purple-500 group-hover:to-pink-500 transition-all duration-300 ${darkMode ? "bg-gray-600/50" : "bg-gray-100/50"}`}
                  >
                    <service.icon
                      className={`group-hover:text-white transition-colors duration-300 ${darkMode ? "text-gray-300" : "text-gray-600"}`}
                      size={24}
                    />
                  </div>
                  <h3 className={`text-base sm:text-lg lg:text-xl font-bold mb-3 sm:mb-4 ${themeClasses.text}`}>
                    <ShinyText text={service.title} />
                  </h3>
                  <p className={`text-sm leading-relaxed ${themeClasses.textSecondary}`}>{service.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Projects Section */}
        <section id="projects" className="py-12 sm:py-16 lg:py-20 relative z-10 prevent-shift">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="text-center mb-8 sm:mb-12 lg:mb-16 optimized-animation"
            >
              <h2 className={`text-2xl sm:text-3xl lg:text-5xl font-bold mb-3 sm:mb-4 lg:mb-6 ${themeClasses.text}`}>
                My Projects
              </h2>
              <p className={`text-base sm:text-lg lg:text-xl max-w-4xl mx-auto ${themeClasses.textSecondary}`}>
                A selection of my best work, showcasing my skills and experience
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 lg:gap-8">
              {projects.map((project, index) => {
                const iconBgClass = "bg-gradient-to-r from-purple-500 to-pink-500"
                const titleGradientClass = "from-purple-500 to-pink-500"
                const techStackBgClass =
                  "bg-gradient-to-r from-purple-500/20 to-pink-500/20 text-purple-600 rounded-full text-xs sm:text-sm border border-purple-500/30"
                const featureBulletClass = "bg-gradient-to-r from-purple-500 to-pink-500"
                const buttonBgClass =
                  "bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
                const buttonBorderClass =
                  "border-purple-500 text-purple-500 hover:bg-gradient-to-r hover:from-purple-500 hover:to-pink-500 hover:text-white"
                const cardBgClass = themeClasses.cardBg
                const cardBorderClass = themeClasses.cardBorder

                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8, delay: index * 0.2 }}
                    viewport={{ once: true }}
                    className={`relative rounded-2xl p-4 sm:p-6 lg:p-8 border transition-all duration-300 hover:scale-105 ${cardBgClass} ${cardBorderClass} hover:border-purple-500/50`}
                  >
                    {project.status === "Coming Soon" && (
                      <span className="absolute top-4 right-4 px-3 py-1 text-xs font-semibold rounded-full bg-orange-500 text-white shadow-md">
                        Coming Soon
                      </span>
                    )}
                    <div className={`flex items-center space-x-3 mb-4 sm:mb-6`}>
                      <div
                        className={`w-10 h-10 sm:w-12 sm:h-12 ${iconBgClass} rounded-lg flex items-center justify-center`}
                      >
                        <Code className="text-white" size={20} />
                      </div>
                      <h3
                        className={`text-lg sm:text-xl lg:text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r ${titleGradientClass}`}
                      >
                        {project.title}
                      </h3>
                    </div>

                    <p className={`mb-4 sm:mb-6 text-sm leading-relaxed ${themeClasses.textSecondary}`}>
                      {project.description}
                    </p>

                    <div className="mb-4 sm:mb-6">
                      <h4 className={`text-base sm:text-lg font-bold mb-2 sm:mb-3 ${themeClasses.text}`}>Tech Stack</h4>
                      <div className="flex flex-wrap gap-2">
                        {project.techStack.map((tech, idx) => (
                          <span
                            key={idx}
                            className={`px-2 sm:px-3 py-1 rounded-full text-xs sm:text-sm ${techStackBgClass}`}
                          >
                            {tech}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="mb-6 sm:mb-8">
                      <h4 className={`text-base sm:text-lg font-bold mb-2 sm:mb-3 ${themeClasses.text}`}>Features</h4>
                      <ul className="space-y-1 sm:space-y-2">
                        {project.features.map((feature, idx) => (
                          <li key={idx} className={`flex items-center space-x-2 ${themeClasses.textSecondary}`}>
                            <div className={`w-1.5 h-1.5 ${featureBulletClass} rounded-full flex-shrink-0`}></div>
                            <span className="text-xs sm:text-sm">{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-4">
                      {project.title === "Yum Express" ? (
                        <>
                          <button
                            disabled={true}
                            className="flex-1 px-3 sm:px-4 py-2 text-white rounded-lg transition-colors font-medium text-center text-sm bg-gray-400 cursor-not-allowed opacity-50"
                          >
                            View Code
                          </button>
                          <button
                            disabled={true}
                            className="flex-1 px-3 sm:px-4 py-2 rounded-lg transition-colors font-medium text-center text-sm border-gray-400 text-gray-400 cursor-not-allowed opacity-50"
                          >
                            Live Demo
                          </button>
                        </>
                      ) : (
                        <>
                          <a
                            href={project.codeLink || "#"}
                            target="_blank"
                            rel="noopener noreferrer"
                            className={`flex-1 px-3 sm:px-4 py-2 text-white rounded-lg transition-colors font-medium text-center text-sm ${buttonBgClass}`}
                          >
                            View Code
                          </a>
                          <a
                            href={project.liveDemoLink || "#"}
                            target="_blank"
                            rel="noopener noreferrer"
                            className={`flex-1 px-3 sm:px-4 py-2 rounded-lg transition-colors font-medium text-center text-sm ${buttonBorderClass}`}
                          >
                            Live Demo
                          </a>
                        </>
                      )}
                    </div>
                  </motion.div>
                )
              })}
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="py-12 sm:py-16 lg:py-20 relative z-10 prevent-shift">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="text-center mb-8 sm:mb-12 lg:mb-16 optimized-animation"
            >
              <h2 className={`text-2xl sm:text-3xl lg:text-5xl font-bold mb-3 sm:mb-4 lg:mb-6 ${themeClasses.text}`}>
                Get In Touch
              </h2>
              <p className={`text-base sm:text-lg lg:text-xl max-w-4xl mx-auto ${themeClasses.textSecondary}`}>
                I'm always open to discussing new opportunities, collaborations, or just having a chat about technology!
              </p>
            </motion.div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 sm:gap-8 lg:gap-12">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8 }}
                viewport={{ once: true }}
                className="space-y-4 sm:space-y-6"
              >
                <div className="space-y-4 sm:space-y-6">
                  {[
                    {
                      icon: Phone,
                      label: "Phone",
                      value: "8962819870",
                      href: "tel:8962819870",
                    },
                    {
                      icon: Mail,
                      label: "Email",
                      value: "muskan.prasad.18@gmail.com",
                      href: "mailto:muskan.prasad.18@gmail.com",
                    },
                    {
                      icon: MapPin,
                      label: "Location",
                      value: "Bhopal, Madhya Pradesh",
                      href: "#",
                    },
                    {
                      icon: Linkedin,
                      label: "LinkedIn",
                      value: "Connect with me",
                      href: "https://www.linkedin.com/in/muskan-prasad-562132275/",
                    },
                    {
                      icon: Github,
                      label: "GitHub",
                      value: "View my projects",
                      href: "https://github.com/CODESbyMUSKAN",
                    },
                  ].map((contact, index) => (
                    <motion.a
                      key={index}
                      href={contact.href}
                      target={contact.href.startsWith("http") ? "_blank" : undefined}
                      rel={contact.href.startsWith("http") ? "noopener noreferrer" : undefined}
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.5, delay: index * 0.1 }}
                      viewport={{ once: true }}
                      className={`flex items-center space-x-3 sm:space-x-4 p-3 sm:p-4 rounded-xl border transition-all duration-300 hover:border-purple-500/50 hover:scale-105 group ${themeClasses.cardBg} ${themeClasses.hoverBg} ${themeClasses.cardBorder}`}
                    >
                      <div className="p-2 sm:p-3 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg text-white group-hover:scale-110 transition-transform duration-300 shadow-lg">
                        <contact.icon size={18} className="sm:w-5 sm:h-5" />
                      </div>
                      <div>
                        <p className={`font-medium text-sm sm:text-base ${themeClasses.text}`}>{contact.label}</p>
                        <p className={`text-xs sm:text-sm ${themeClasses.textSecondary}`}>{contact.value}</p>
                      </div>
                    </motion.a>
                  ))}
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
                viewport={{ once: true }}
                className={`p-4 sm:p-6 lg:p-8 rounded-2xl border max-w-lg mx-auto ${themeClasses.cardBg} ${themeClasses.cardBorder}`}
              >
                <h3 className={`text-lg sm:text-xl lg:text-2xl font-bold mb-4 sm:mb-6 ${themeClasses.text}`}>
                  Send a Message
                </h3>
                <form className="space-y-4 sm:space-y-6" onSubmit={handleSendMessage}>
                  <div>
                    <label
                      htmlFor="contact-name"
                      className={`block text-sm font-medium mb-2 ${themeClasses.textSecondary}`}
                    >
                      Name
                    </label>
                    <input
                      type="text"
                      id="contact-name"
                      className={`w-full px-3 sm:px-4 py-2 sm:py-3 rounded-lg border transition-all duration-200 focus:ring-2 focus:ring-purple-500 focus:border-transparent text-sm sm:text-base ${themeClasses.inputBg} ${themeClasses.inputBorder} ${themeClasses.text}`}
                      placeholder="Your Name"
                      value={contactName}
                      onChange={(e) => setContactName(e.target.value)}
                      required
                    />
                  </div>
                  <div>
                    <label
                      htmlFor="contact-email"
                      className={`block text-sm font-medium mb-2 ${themeClasses.textSecondary}`}
                    >
                      Email
                    </label>
                    <input
                      type="email"
                      id="contact-email"
                      className={`w-full px-3 sm:px-4 py-2 sm:py-3 rounded-lg border transition-all duration-200 focus:ring-2 focus:ring-purple-500 focus:border-transparent text-sm sm:text-base ${themeClasses.inputBg} ${themeClasses.inputBorder} ${themeClasses.text}`}
                      placeholder="your.email@example.com"
                      value={contactEmail}
                      onChange={(e) => setContactEmail(e.target.value)}
                      required
                    />
                  </div>
                  <div>
                    <label
                      htmlFor="contact-message"
                      className={`block text-sm font-medium mb-2 ${themeClasses.textSecondary}`}
                    >
                      Message
                    </label>
                    <textarea
                      id="contact-message"
                      rows={4}
                      className={`w-full px-3 sm:px-4 py-2 sm:py-3 rounded-lg border transition-all duration-200 focus:ring-2 focus:ring-purple-500 focus:border-transparent resize-none text-sm sm:text-base ${themeClasses.inputBg} ${themeClasses.inputBorder} ${themeClasses.text}`}
                      placeholder="Your message here..."
                      value={contactMessage}
                      onChange={(e) => setContactMessage(e.target.value)}
                      required
                    ></textarea>
                  </div>
                  <button
                    type="submit"
                    className="w-full px-4 sm:px-6 py-2 sm:py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-lg hover:from-purple-600 hover:to-pink-600 transform hover:scale-105 transition-all duration-200 font-medium shadow-lg hover:shadow-xl text-sm sm:text-base"
                  >
                    Send Message
                  </button>
                </form>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer
          className={`py-6 sm:py-8 border-t transition-colors duration-300 relative z-10 ${themeClasses.navBorder}`}
        >
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <p className={`text-sm ${themeClasses.textMuted}`}>© {new Date().getFullYear()} Muskan Prasad.</p>
            </div>
          </div>
        </footer>

        {/* Scroll to Top Button */}
        <AnimatePresence>
          {showScrollTop && (
            <motion.button
              initial={{ opacity: 0, scale: 0 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0 }}
              onClick={scrollToTop}
              className="fixed bottom-6 sm:bottom-8 right-6 sm:right-8 p-2 sm:p-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-110 z-50"
            >
              <ArrowUp size={18} className="sm:w-5 sm:h-5" />
            </motion.button>
          )}
        </AnimatePresence>
      </div>
    </div>
  )
}
