import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Chrome, Github } from "lucide-react" // Using Chrome for Google icon

export default function SignInForm() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-50 dark:bg-gray-950">
      <div className="w-full max-w-md rounded-lg border bg-white p-8 shadow-lg dark:border-gray-800 dark:bg-gray-900">
        <div className="flex flex-col items-center space-y-6">
          {/* Logo */}
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-black dark:bg-white">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-6 w-6 text-white dark:text-black"
            >
              <path d="M12 2L2 22H22L12 2Z" />
              <path d="M12 2L17 12L7 12L12 2Z" />
            </svg>
          </div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-50">Sign in to v0</h1>
          <p className="text-center text-sm text-gray-500 dark:text-gray-400">
            Sign in to v0 using your Vercel account.
          </p>

          {/* Email Form */}
          <form className="w-full space-y-4">
            <Input type="email" placeholder="Email Address" className="h-10" />
            <Button
              type="submit"
              className="w-full bg-gray-900 text-white hover:bg-gray-800 dark:bg-gray-50 dark:text-gray-900 dark:hover:bg-gray-200"
            >
              Continue with Email
            </Button>
          </form>

          {/* Separator */}
          <div className="relative flex w-full items-center justify-center">
            <Separator className="w-full" />
            <span className="absolute bg-white px-2 text-xs text-gray-400 dark:bg-gray-900 dark:text-gray-500">OR</span>
          </div>

          {/* Social Login Buttons */}
          <div className="w-full space-y-3">
            <Button
              variant="outline"
              className="w-full border-gray-300 text-gray-700 hover:bg-gray-50 dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-800 bg-transparent"
            >
              <Chrome className="mr-2 h-4 w-4" />
              Continue with Google
            </Button>
            <Button
              variant="outline"
              className="w-full border-gray-300 text-gray-700 hover:bg-gray-50 dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-800 bg-transparent"
            >
              <Github className="mr-2 h-4 w-4" />
              Continue with GitHub
            </Button>
          </div>

          {/* Other Options */}
          <a href="#" className="text-sm text-gray-500 hover:underline dark:text-gray-400">
            Show other options
          </a>

          {/* Sign Up Link */}
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Don't have an account?{" "}
            <a href="#" className="font-medium text-blue-600 hover:underline dark:text-blue-400">
              Sign Up
            </a>
          </p>
        </div>
      </div>
    </div>
  )
}
